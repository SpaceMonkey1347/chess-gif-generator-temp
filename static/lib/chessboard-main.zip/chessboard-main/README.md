# This project has been supercede by a new project
This project is no longer maintained, see Wukong JS instead -<br>
a javascript port of Wukong chess engine with UCI support + library like API:<br>
https://github.com/maksimKorzh/wukongJS

# Experimental javascript chess board
A pure javascript chess board widget that knows rules of chess

# Features
 - two click/drag-n-drop moving pieces
 - navigate through game moves (move stack)
 - move validation
 - perft
 - FEN parsing
 - PGN like moves sequence parsing
 - console debugging

# Live demo
https://maksimkorzh.github.io/chessboard/

# How to use it (CRASH COURSE)
[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/QFY1Mbcueno/0.jpg)](https://www.youtube.com/watch?v=QFY1Mbcueno&feature=youtu.be)

